# AI ረዳት — Android app

GitHub Actions በራሱ APK ይገነባል። ፕሮጀክቱን repository root ላይ አስቀምጡ (app/, settings.gradle, build.gradle).

Workflow: Actions > Build AI App APK > Run workflow.
APK: Actions run > Artifacts > AIApp-debug-apk.
